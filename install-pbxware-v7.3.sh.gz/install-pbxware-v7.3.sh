#!/bin/bash

VERFULL="7.3.0"
VER="7.3"
URL="https://downloads.bicomsystems.com/updates-7.3.0"
    
function yesno_input () {
        prompt=$1
        rv=""
        while [ -z "$rv" ]; do
                read -s -n 1 -p "$prompt" yesno
                rv=`echo $yesno | pcregrep -i "y|n$"`
                if [ -z "$rv" ]; then
                        echo " Please answer with Y or N!"
                fi
        done
        YN=$rv
        echo $rv
}


function exit_on_err () {
	if [ "$1" != "0" ]; then
		echo -e "\n\n   \033[1;31mFAILED!\033[0m \n"
		exit $1
	fi
}

echo -e "\n\033[1;32m*\033[0m  This is PBXWare v$VERFULL installation script."
echo -e "\033[1;32m*\033[0m  Please note, this script will stop and wipe "
echo -e "\033[1;32m*\033[0m  out any previous installation of PBXWare v$VERFULL!\n"

yesno_input "Do you want to proceed (y/n): "
if [ "$YN" = "n" -o "$YN" = "N" ]; then
	exit 0
fi

cd /opt/

echo " "
echo -e "\033[1;34m[*]\033[0m Downloading Setup Wizard ...\n"

rc=1
while [ "$rc" != "0" ]
do
	wget -c $URL/httpd_${VER}_x64.tar.bz2
	rc=$?
done

echo -e "\033[1;34m[*]\033[0m  Downloading PBXware ...\n"

rc=1
while [ "$rc" != "0" ] 
do
        wget -c $URL/pbxware_${VER}_x64.tar.bz2
	rc=$?
done

echo -e "\033[1;34m[*]\033[0m  Stop and remove previous instance ...\n"

if [ -e "/opt/httpd" ]; then
	/opt/httpd/sh/stop
	rm -fr /opt/httpd
	exit_on_err $?
fi

if [ -e "/opt/pbxware" ]; then
	/opt/pbxware/sh/pbxware stop
        rm -fr /opt/pbxware
	exit_on_err $?
fi


echo -e "\033[1;34m[*]\033[0m  Extracting Setup Wizard ...\n"

tar --numeric-owner -xjf httpd_${VER}_x64.tar.bz2
exit_on_err $?

echo -e "\033[1;34m[*]\033[0m  Extracting PBXware ...\n"

tar --numeric-owner -xjf pbxware_${VER}_x64.tar.bz2
exit_on_err $?

echo -e "\033[1;34m[*]\033[0m  Cleanup ...\n"

rm -fv httpd_${VER}_x64.tar.bz2 pbxware_${VER}_x64.tar.bz2
exit_on_err $?

echo -e "\033[1;34m[*]\033[0m  Unpacking each one to relevant location ...\n"

cd /opt/httpd
exit_on_err $?

echo -e "\033[1;34m[*]\033[0m  Downloading Setup Wizard ...\n"

rc=1
while [ "$rc" != "0" ] 
do
        wget -c $URL/ioncube/setup_wizard.tar.gz
	rc=$?
done

echo -e "\033[1;34m[*]\033[0m  Extracting Setup Wizard ...\n"

tar --numeric-owner -xzf setup_wizard.tar.gz
exit_on_err $?

echo -e "\033[1;34m[*]\033[0m  Replacing Setup Wizard ...\n"
rm -rf www-safe
exit_on_err $?
mv setup_wizard www-safe
exit_on_err $?

echo -e "\033[1;34m[*]\033[0m  Cleanup ...\n"

rm -fv setup_wizard.tar.gz
exit_on_err $?


cd /opt/pbxware/pw
exit_on_err $?

echo -e "\033[1;34m[*]\033[0m  Downloading PBXware ...\n"

rc=1
while [ "$rc" != "0" ] 
do
        wget -c $URL/ioncube/pbxware.tar.gz
	rc=$?
done

echo -e "\033[1;34m[*]\033[0m  Extracting PBXware ...\n"

tar --numeric-owner -xzf pbxware.tar.gz
exit_on_err $?

echo -e "\033[1;34m[*]\033[0m  Cleanup ...\n"

rm -fv pbxware.tar.gz
exit_on_err $?


cd /opt/pbxware/pw/gui
exit_on_err $?

echo -e "\033[1;34m[*]\033[0m  Downloading GUI ...\n"

rc=1
while [ "$rc" != "0" ] 
do
        wget -c $URL/ioncube/sitemanager.tar.gz
	rc=$?
done

echo -e "\033[1;34m[*]\033[0m  Replacing GUI ...\n"

tar --numeric-owner -xzf sitemanager.tar.gz
exit_on_err $?
rm -rf admin
exit_on_err $?
mv sitemanager/admin .
exit_on_err $?
rm -rf sitemanager
exit_on_err $?

cd /opt/pbxware/pw/home
exit_on_err $?

echo -e "\033[1;34m[*]\033[0m  Downloading CRM Integration Service ...\n"

rc=1
while [ "$rc" != "0" ] 
do
        wget -c $URL/ioncube/crmiservice.tar.gz
	rc=$?
done

echo -e "\033[1;34m[*]\033[0m  Replacing CRM Integration Service ...\n"

tar --numeric-owner -xzf crmiservice.tar.gz
exit_on_err $?

echo -e "\033[1;34m[*]\033[0m  Cleanup ...\n"

rm -fv crmiservice.tar.gz
exit_on_err $?

echo -e "\n\n   \033[1;32mDONE.\033[0m "
echo "   Please start PBXware services manually. "

exit 0
